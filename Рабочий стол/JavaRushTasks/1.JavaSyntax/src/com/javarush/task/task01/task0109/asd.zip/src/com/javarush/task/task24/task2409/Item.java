package com.javarush.task.task24.task2409;

/**
 * Created by ruslan on 07.02.17.
 */
public interface Item {
    int getId();
    double getPrice();
    String getTM();
}
