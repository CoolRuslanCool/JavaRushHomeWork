package com.javarush.task.task26.task2601;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/*
Почитать в инете про медиану выборки
*/
public class Solution {

    public static void main(String[] args) {
    }

    public static Integer[] sort(Integer[] array) {
        ArrayList<Integer> mas = new ArrayList<>(Arrays.asList(array));
        Collections.sort(mas);
        int mer, cou = 0;
        if (mas.size()%2 == 1) mer = mas.get(mas.size()/2);
        else mer = (int)Math.abs((mas.get(mas.size()/2)+mas.get((mas.size()/2)-1))/2.0);

        while (mas.size()> 0) {
            array[cou] = getMer(mas, mer, mer);
            mas.remove(array[cou++]);
        }
        return array;
    }

    public static Integer getMer(ArrayList<Integer> mas, int num1, int num2) {
        if (mas.contains(num1)) return num1;
        else if (mas.contains(num2)) return num2;
        else return getMer(mas, num1 - 1, num2 + 1);

    }
}
