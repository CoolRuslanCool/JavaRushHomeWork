package com.javarush.task.task30.task3008;

/**
 * Created by ruslan on 28.02.17.
 */
public enum MessageType {
    NAME_REQUEST,
    USER_NAME,
    NAME_ACCEPTED,
    TEXT,
    USER_ADDED,
    USER_REMOVED
}
