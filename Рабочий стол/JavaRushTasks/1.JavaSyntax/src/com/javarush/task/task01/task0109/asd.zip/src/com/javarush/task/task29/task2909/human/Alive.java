package com.javarush.task.task29.task2909.human;

/**
 * Created by ruslan on 27.02.17.
 */
public interface Alive {
    void live();
}
