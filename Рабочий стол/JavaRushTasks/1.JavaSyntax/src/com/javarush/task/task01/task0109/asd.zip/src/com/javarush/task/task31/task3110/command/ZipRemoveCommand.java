package com.javarush.task.task31.task3110.command;

/**
 * Created by ruslan on 04.03.17.
 */
public class ZipRemoveCommand extends ZipCommand {
    @Override
    public void execute() throws Exception {

    }
}
