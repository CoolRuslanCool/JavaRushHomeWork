package com.javarush.task.task24.task2407;

public interface Pet {
    public Sayable toSayable(int i);
}
